# Hello !
I hope you're having fun rn~

Here are some resources you will need during this session

### Basic Aframe structure
<!DOCTYPE html>
<html lang="en">
  <head>
    <!Import aframe>
    <script src="https://aframe.io/releases/1.0.0/aframe.min.js"></script>
    <!import ar.js>
    <script src="https://jeromeetienne.github.io/AR.js/aframe/build/aframe-ar.js"></script>
  </head>
  <body>
    <a-scene embedded arjs="sourceType: webcam ; videoTexture: true; debugUIEnabled: false;" ar-mode-ui="enabled: false" vr-mode-ui="enabled: false">
    </a-scene>
  </body>
</html>

### for marker based 
<script src="https://aframe.io/releases/1.0.0/aframe.min.js"></script>


### for superimposed
<!the folllowing script is needed to animate gltf files>
<script src="https://cdn.jsdelivr.net/gh/c-frame/aframe-extras@7.2.0/dist/aframe-extras.min.js"></script>

### for image tracking 
<html>
  <head>
    <script src="https://aframe.io/releases/1.5.0/aframe.min.js"></script>
    <!the following script is needed for image tracking>
    <script src="https://cdn.jsdelivr.net/npm/mind-ar@1.2.5/dist/mindar-image-aframe.prod.js"></script>
  </head>
  <body>
    <a-scene mindar-image="imageTargetSrc: https://cdn.glitch.global/bcb3f705-020b-4ca7-a054-059a1a44396b/targets.mind?v=1708344241933;" color-space="sRGB" renderer="colorManagement: true, physicallyCorrectLights" vr-mode-ui="enabled: false" device-orientation-permission-ui="enabled: false">
      <!the mindar-image contains link to the image tracking file>
    </a-scene>
  </body>
</html>
